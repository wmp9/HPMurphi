From "Fox, Maria, and Derek Long. "Modelling mixed discrete-continuous domains for planning." Journal of Artificial Intelligence Research 27.1 (2006): 235-297."
and
"Della Penna, Giuseppe, et al. "UPMurphi: a tool for universal planning on PDDL+ problems." Proc. 19th Int. Conf. Aut. Planning and Scheduling (ICAPS). 2009."
1) car.pddl
2) planetary_lander.pddl

From  "Della Penna, Giuseppe, Daniele Magazzeni, and Fabio Mercorio. "A universal planning system for hybrid domains." Applied Intelligence 36.4 (2012): 932-959."
2) cooling_system.pddl 
3) nonlinear_generator.pddl

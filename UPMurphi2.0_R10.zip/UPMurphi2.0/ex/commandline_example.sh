./planety-SS99 -l 200 -m 100 -format:pddl -search:o -output plans.pddl

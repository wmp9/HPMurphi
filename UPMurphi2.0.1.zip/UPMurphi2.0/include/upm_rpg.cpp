/*
 * upm_rpg.cpp
 *
 *  Created on: 7 Mar 2014
 *      Author: k1328088
 */

#include "upm_rpg.hpp"
#include <std>
#include <set>
#include <string>

upm_rpg::upm_rpg() {
	// TODO Auto-generated constructor stub

}


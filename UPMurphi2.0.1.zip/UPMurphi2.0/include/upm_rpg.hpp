/*
 * upm_rpg.hpp
 *
 *  Created on: 7 Mar 2014
 *      Author: k1328088
 */

#ifndef UPM_RPG_HPP_
#define UPM_RPG_HPP_

class upm_rpg {
public:
	upm_rpg();
};

#endif /* UPM_RPG_HPP_ */
